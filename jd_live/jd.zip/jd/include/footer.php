
  <tr>
    <td align="left" valign="top"><img src="images/bgline.png" width="985" height="2" /></td>
  </tr>
  <tr>
    <td align="right" valign="top" class="copyr">Copyright &copy; 2013 System Administrator. All Right Reserved. &nbsp; </td>
  </tr>
</table>

<map name="Map" id="Map"><area shape="rect" coords="7,8,80,30" href="index.php" target="_self" />
</map></body>
</html>
